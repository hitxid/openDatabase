package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm15 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("SELECT COUNT(*) FROM emp WHERE emp_no = ? ");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "16");
		  			rs = pstmt.executeQuery();
		  			
		  			int result = 0;
		  			if( rs != null && rs.next() && rs.getInt(1) > 0  ) {
			  			sql = new StringBuffer("DELETE FROM emp WHERE emp_no = ? ");
			  			pstmt.close();
			  			pstmt = conn.prepareStatement(sql.toString());
			  			pstmt.setString(1, "16");
			  			result = pstmt.executeUpdate();
			  			System.out.println("����� ����, ���� ��� :"+ result);
		  			}
		  			
		  			sql = new StringBuffer("INSERT INTO emp(emp_no, e_nm, age, dept_no, POSITION, salary) ");
		  			sql.append("VALUES(?, ?, ?, ?, ?, ?)");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "16");
		  			pstmt.setString(2, "������");
		  			pstmt.setString(3, "19");
		  			pstmt.setString(4, "5");
		  			pstmt.setString(5, "����");
		  			pstmt.setString(6, "5100000");
		  			result = pstmt.executeUpdate();
		  			System.out.println("��� ��� ��� :"+ result);
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( pstmt != null ) pstmt.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
