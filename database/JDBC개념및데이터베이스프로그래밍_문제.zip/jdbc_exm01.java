package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm01 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement stmt = null;
			ResultSet rsTable = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			stmt = conn.prepareStatement("SELECT COUNT(*) FROM voucher ");
		  			rsTable = stmt.executeQuery();
		  			if( rsTable != null && rsTable.next()){
		  				System.out.println("voucher row count:"+rsTable.getInt(1));
		  			}
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( stmt != null ) stmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
