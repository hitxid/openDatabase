package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class jdbc_exm16 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement pstmt = null;
			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			conn.setAutoCommit(false);
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("INSERT INTO dept(dept_no, branch_nm, dept_nm) ");
		  			sql.append("VALUES( ?, ?, ?)");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "7");
		  			pstmt.setString(2, "ö����");
		  			pstmt.setString(3, "�����");
		  			int result = 0;
		  			result = pstmt.executeUpdate();
		  			System.out.println("���� �μ� ��� ��� :"+ result);
		  			
		  			sql = new StringBuffer("INSERT INTO emp(emp_no, e_nm, age, dept_no, POSITION, salary) ");
		  			sql.append("VALUES(?, ?, ?, ?, ?, ?)");
		  			pstmt.close();
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "17");
		  			pstmt.setString(2, "������");
		  			pstmt.setString(3, "21");
		  			pstmt.setString(4, "7");
		  			pstmt.setString(5, "����");
		  			pstmt.setString(6, "4100000");
		  			result = pstmt.executeUpdate();
		  			System.out.println("��� ��� ��� :"+ result);
		  			conn.commit();
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
				conn.rollback();
			}finally{
				if( pstmt != null ) pstmt.close();
				if( conn != null ) {
					conn.setAutoCommit(true);
					conn.close();
				}
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
