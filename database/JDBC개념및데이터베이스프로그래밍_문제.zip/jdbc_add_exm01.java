package database;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_add_exm01 {
	public static void main(String[] args) {
  		File file = null;
  		FileWriter fw = null;
  		BufferedWriter bw = null;
  		
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement stmt = null;
			ResultSet rsTable = null;
	  		
	  		file = new File("C:\\Temp\\jdbc16result.txt");
	  		if( file.exists() != false )
	  			file.createNewFile();
	  		fw = new FileWriter(file);
	  		bw = new BufferedWriter(fw);
	  		
			try{
				Class.forName("org.mariadb.jdbc.Driver");
				bw.write("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			bw.write("Not connected!!!\n");
		  		}else{
		  			bw.write("Connected!!!\n");
		  			StringBuffer sql = new StringBuffer("SELECT a.c_id, a.c_name, a.age, COUNT(*) AS voucherCount\r\n");
		  			sql.append("  FROM customer AS a \r\n");
		  			sql.append("  INNER JOIN voucher AS b\r\n");
		  			sql.append("  ON a.c_id = b.c_id\r\n");
		  			sql.append(" GROUP BY a.c_id, a.c_name, a.age");
		  			
		  			stmt = conn.prepareStatement(sql.toString());
		  			rsTable = stmt.executeQuery();
		  			while(rsTable != null && rsTable.next()){
		  				bw.write(rsTable.getString(1)+"\t"+rsTable.getString(2)+"\t"+rsTable.getString(3)+"\t"+rsTable.getString(4)+"\n");
		  			}
		  		}
			}catch(Exception e){
				bw.write("error:"+e.toString()+"\n");
			}finally{
				if( stmt != null ) stmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}finally {
			try {
				if( bw != null ) bw.close();
				if( fw != null ) fw.close();
			}catch(Exception closeEx) {
				System.out.println("closeError:"+ closeEx.toString());
			}
		}
	}
}
