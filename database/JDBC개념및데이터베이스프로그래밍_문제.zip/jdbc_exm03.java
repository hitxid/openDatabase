package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm03 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement stmt = null;
			ResultSet rsTable = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("SELECT a.c_id, a.c_name, a.age, COUNT(*) AS voucherCount\r\n");
		  			sql.append("  FROM customer AS a \r\n");
		  			sql.append("  INNER JOIN voucher AS b\r\n");
		  			sql.append("  ON a.c_id = b.c_id\r\n");
		  			sql.append(" GROUP BY a.c_id, a.c_name, a.age");
		  			
		  			stmt = conn.prepareStatement(sql.toString());
		  			rsTable = stmt.executeQuery();
		  			while(rsTable != null && rsTable.next()){
		  				System.out.println(rsTable.getString(1)+"\t"+rsTable.getString(2)+"\t"+rsTable.getString(3)+"\t"+rsTable.getString(4));
		  			}
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( stmt != null ) stmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
