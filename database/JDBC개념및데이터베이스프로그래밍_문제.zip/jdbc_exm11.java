package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm11 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement pstmt = null;
			ResultSet rsTable = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("UPDATE dept SET branch_nm = replace(branch_nm, ?, ?) ");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "����");
		  			pstmt.setString(2, "��");
		  			int result = pstmt.executeUpdate();
		  			System.out.println("update result :"+ result);
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( pstmt != null ) pstmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
