package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class jdbc_exm14 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement pstmt = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("DELETE FROM customer WHERE c_id = ? ");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "22");
		  			int result = pstmt.executeUpdate();
		  			System.out.println("delete result :"+ result);
		  			
		  			sql = new StringBuffer("INSERT INTO customer(c_id, c_name, c_mobile, level, zipcode, age) ");
		  			sql.append("VALUES(?, ?, ?, ?, ?, ?)");
		  			pstmt.close();
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "22");
		  			pstmt.setString(2, "������");
		  			pstmt.setString(3, "010-0000-0011");
		  			pstmt.setString(4, "GREEN");
		  			pstmt.setString(5, "30101");
		  			pstmt.setString(6, "19");
		  			result = pstmt.executeUpdate();
		  			System.out.println("insert result :"+ result);
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( pstmt != null ) pstmt.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
