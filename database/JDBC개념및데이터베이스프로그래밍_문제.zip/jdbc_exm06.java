package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm06 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement stmt = null;
			ResultSet rsTable = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("SELECT sale_store, SUM(quantity)\r\n");
		  			sql.append("  FROM sales\r\n");
		  			sql.append(" GROUP BY sale_store");
		  			stmt = conn.prepareStatement(sql.toString());
		  			rsTable = stmt.executeQuery();
		  			while(rsTable != null && rsTable.next()){
		  				System.out.println(rsTable.getString(1)+"\t"+rsTable.getString(2));
		  			}
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( stmt != null ) stmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
