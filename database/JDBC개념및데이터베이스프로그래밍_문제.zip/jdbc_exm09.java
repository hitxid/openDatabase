package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class jdbc_exm09 {
	public static void main(String[] args) {
		try{
			Connection conn = null;
			String url= "jdbc:mariadb://127.0.0.1:3307/test_user";
			PreparedStatement pstmt = null;
			ResultSet rsTable = null;

			try{
				Class.forName("org.mariadb.jdbc.Driver");
				System.out.println("Connect.....");
				conn=DriverManager.getConnection(url,"root","1234");
		  		if( conn == null ) {
		  			System.out.println("Not connected!!!");
		  		}else{
		  			System.out.println("Connected!!!");
		  			StringBuffer sql = new StringBuffer("INSERT INTO emp(emp_no, e_nm, age, dept_no, POSITION, salary) ");
		  			sql.append("VALUES(?, ?, ?, ?, ?, ?)");
		  			pstmt = conn.prepareStatement(sql.toString());
		  			pstmt.setString(1, "15");
		  			pstmt.setString(2, "������");
		  			pstmt.setString(3, "31");
		  			pstmt.setString(4, "5");
		  			pstmt.setString(5, "����");
		  			pstmt.setString(6, "3100000");
		  			int result = pstmt.executeUpdate();
		  			System.out.println("update result :"+ result);
		  			if( pstmt != null ) pstmt.close();
		  			pstmt = conn.prepareStatement("SELECT COUNT(*) FROM emp where dept_no= 5 ");
		  			rsTable = pstmt.executeQuery();
		  			if( rsTable != null && rsTable.next()){
		  				System.out.println("�������� �ο���:"+rsTable.getInt(1));
		  			}
		  		}
			}catch(Exception e){
				System.out.println("error:"+e.toString());
			}finally{
				if( pstmt != null ) pstmt.close();
				if( rsTable != null ) rsTable.close();
				if( conn != null ) conn.close();
			}
		}catch(Exception exx){
			System.out.println("error : " + exx.toString());
		}
	}
}
