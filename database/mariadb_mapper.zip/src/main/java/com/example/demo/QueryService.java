package com.example.demo;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QueryService {
	@Autowired
	QueryDao dao;
	
	public List<HashMap<String, Object>> getList(){
		return dao.getList();
	}
	
	public HashMap<String, Object> getData(HashMap<String, Object> map){
		return dao.getData(map);
	}
    
    public int insData(HashMap<String, Object> map) {
    	return dao.insData(map);
    }
    
    public int updateData(HashMap<String, Object> map) {
    	return dao.updateData(map);
    }
    
    public int deleteData(HashMap<String, Object> map) {
    	return dao.deleteData(map);
    }
}
