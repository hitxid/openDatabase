package com.example.demo;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface QueryDao {
    public List<HashMap<String, Object>> getList();
    
    public HashMap<String, Object> getData(HashMap<String, Object> map);
    
    public int insData(HashMap<String, Object> map);
    
    public int updateData(HashMap<String, Object> map);
    
    public int deleteData(HashMap<String, Object> map);
}
