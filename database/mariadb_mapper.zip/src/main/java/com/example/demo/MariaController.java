package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MariaController {

	@Autowired
    QueryService qservice;
	
	@GetMapping("/")
	@ResponseBody
    public  HashMap<String, Object> wellHome() {
		HashMap<String, Object> res = new HashMap<String, Object>();
		res.put("welcome", "hello");
        return res;
    }
	
	@GetMapping("/List")
	@ResponseBody
    public List<HashMap<String, Object>> qlist() {
		List<HashMap<String, Object>> res = new ArrayList<HashMap<String, Object>>();
		res = qservice.getList();
        return res;
	}
	
	@GetMapping("/getData")
	@ResponseBody
    public HashMap<String, Object> getData() {
		HashMap<String, Object> res = null;
		HashMap<String, Object> schres = new HashMap<String,Object>();
		
		schres.put("cId", "10");
		res = qservice.getData(schres);
        return res;
    }
	
	@GetMapping("/insData")
	@ResponseBody
    public int insData() {
		int res = 0;
		HashMap<String, Object> schres = new HashMap<String,Object>();
		
		schres.put("cId", "50");
		schres.put("cName", "스프링스");
		schres.put("cMobile", "010-0000-0000");
		schres.put("level", "GREEN");
		schres.put("zipcode", "12394");
		schres.put("age", "52");
		
		res = qservice.insData(schres);
        return res;
    }
	
	@GetMapping("/updateData")
	@ResponseBody
    public int updateData() {
		int res = 0;
		HashMap<String, Object> schres = new HashMap<String,Object>();
		
		schres.put("cId", "3");
		schres.put("cMobile", "010-0000-0000");
		
		res = qservice.updateData(schres);
        return res;
    }
	
	@GetMapping("/deleteData")
	@ResponseBody
    public int deleteData() {
		int res = 0;
		HashMap<String, Object> schres = new HashMap<String,Object>();
		
		schres.put("cId", "50");
		
		res = qservice.deleteData(schres);
        return res;
    }

}
